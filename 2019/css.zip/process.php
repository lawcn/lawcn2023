<?php

        $con = mysqli_connect("localhost", "yedco746_lawcn", "lawcn1720", "yedco746_lawcn");
	if (!$con) {
		echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	}
	mysqli_query($con,"SET NAMES 'utf8'")or die(mysqli_error($con));;
	mysqli_query($con,'SET character_set_connection=utf8')or die(mysqli_error($con));;
	mysqli_query($con,'SET character_set_client=utf8')or die(mysqli_error($con));;
	mysqli_query($con,'SET character_set_results=utf8')or die(mysqli_error($con));;
        
        
if($_SERVER['HTTP_REFERER']=="http://lawcn.com.br/"){

$email=$_POST["email"];
$name = $_POST["name"];
$query = mysqli_query($con,"select * from lista_email where email like '".$email."'");

if(mysqli_num_rows($query)>0){
   echo "<h6><font color=\"#f7a73b\"><b>E-mail already registered!</b></font> </h6>";
}else{
 mysqli_query($con,"insert into lista_email(id,nome,email) values(null,'".$name."','".$email."')")or die(mysqli_error($con));
echo "<h6><font color=\"#f7a73b\"><b>Successful registration!</b></font> </h6>";
}
}

?>
